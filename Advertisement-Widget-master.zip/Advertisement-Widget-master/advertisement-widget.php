<?php
/*
Plugin Name: Advertisement Widget
Plugin URI:
Description: Advertisement Widget
Version: 1.0
Author:
Author URI:
License: GPLv2 or later
Text Domain: advertisement-widget
Domain Path: /languages/
 */

require_once plugin_dir_path( __FILE__ ) . "widgets/class.advertisementwidget.php";

function advertisement_load_textdomain() {
    load_plugin_textdomain( 'advertisement', false, plugin_dir_path( __FILE__ ) . "languages/" );
}

add_action( 'plugins_loaded', 'advertisement_load_textdomain' );

function advertisement_register() {
    register_widget( 'AdvertisementWidget' );
}

add_action( 'widgets_init', 'advertisement_register' );

function advertisement_admin_enqueue_scripts( $screen ) {
    if ( $screen == "widgets.php" ) {
        wp_enqueue_media();
        wp_enqueue_script( "advertisement-widget-js", plugin_dir_url( __FILE__ ) . "js/media-gallery.js", array( "jquery" ), "1.0", 1 );
    }
}

add_action( "admin_enqueue_scripts", "advertisement_admin_enqueue_scripts" );
